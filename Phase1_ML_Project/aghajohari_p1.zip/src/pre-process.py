import nltk
# nltk.download('punkt')
nltk.download('wordnet')
sentence = """Rasool hates machine learning and he doesn't have the 
confidence needed to apply for it"""
d = nltk.word_tokenize(sentence)
print(d)
string.punc
